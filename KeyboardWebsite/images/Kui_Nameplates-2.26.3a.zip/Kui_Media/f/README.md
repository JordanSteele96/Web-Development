The following files are released under licenses which allow use in at least non-commercial applications.

francois.ttf, Francois One by [New Typography](newtypography.co.uk) under [SIL Open Font License](http://scripts.sil.org/cms/scripts/page.php?item_id=OFL_web)

roboto.ttf, Roboto Condensed Bold by [Google](fonts.google.com) under [Apache License](https://raw.githubusercontent.com/google/roboto/master/LICENSE)
